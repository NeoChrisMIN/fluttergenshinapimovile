const urlBaseGlobal = "http://10.0.2.2:80"; //"http://192.168.100.216:80"; //"http://10.0.2.2:80";
